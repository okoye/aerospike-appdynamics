'''
settings the python way
'''
LIB_DIR = '/home/vagrant/citrusleaf_client_swig_2.1.11/swig/python'
PORT = None #using default 3000
HOST = None #using current host as default
DB_FILE = '/tmp/aerospike_appdynamics.sqlite'
